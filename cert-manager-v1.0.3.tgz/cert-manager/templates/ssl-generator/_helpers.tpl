{{- define "baseDomain" -}}
{{- printf "%s" .Values.dns.baseDomain | trunc 63 | trimSuffix "." -}}
{{- end -}}
